<?php
return [
    'host' => '127.0.0.1',
    'user' => 'root',
    'passwor' => 'password',
    'database' => 'php-mvc'
];