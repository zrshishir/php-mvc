</section>

<footer>
  <p>Footer</p>
</footer>

</body>
</html>