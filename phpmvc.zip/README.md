# php-mvc
A project using raw php with mvc design pattern and cookie. front end validation with javascript
1. database connection credential on DatabaseConnection 
